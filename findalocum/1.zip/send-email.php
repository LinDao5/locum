<?php 
  $intRef=$_POST["intRef"];
  $date=$_POST["date"];
  $rate=$_POST["rate"];
  $store=$_POST["store"];
  $timing=$_POST["timing"];
  $testTime=$_POST["testTime"];
  $speReq=$_POST["speReq"];
 if($intRef == "" || $intRef == NULL){echo "<script>alert('Please Enter Internal Reference');</script>";}
 if($date == "" || $date == NULL){echo "<script>alert('Please Enter Date');</script>";}
 if($rate == "" || $rate == NULL){echo "<script>alert('Please Enter Rate');</script>";}
 if($store == "" || $store == NULL){echo "<script>alert('Please Enter Store Name And Address');</script>";}
 if($timing == "" || $timing == NULL){echo "<script>alert('Please Select Timings');</script>";}
 if($testTime == "" || $testTime == NULL){echo "<script>alert('Please Enter Testing Time');</script>";}
 if($speReq == "" || $speReq == NULL){$speReq = "Nill";}
 
 $receiver="musman5264@gmail.com";
 $subject="Contact Request from $store";

$message = "
<html>
<head>
<title>Locum Contact Details</title>
</head>
<body>
<table width='50%' border='0' align='center' cellpadding='0' cellspacing='0'>
  <tr>
    <td colspan='2' align='center' valign='top'><img src='img/logo.jpg' width='140' height='140'></td>
  </tr>
  <tr>
    <td colspan='2' align='center' valign='center' style='font-size: 30px'>$store</td>
  </tr>
  <tr>
    <td width='50%' align='right' style='font-size: 20px'>&nbsp;</td>
    <td align='left' style='font-size: 30px'>&nbsp;</td>
  </tr>
  <tr>
    <td align='right' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 5px 7px 0;'>Internal Reference:</td>
    <td align='left' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 0 7px 5px;'>".$intRef."</td>
  </tr>
  <tr>
    <td align='right' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 5px 7px 0;'>Date</td>
    <td align='left' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 0 7px 5px;'>".$date."</td>
  </tr>
  <tr>
    <td align='right' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 5px 7px 0;'>Rate:</td>
    <td align='left' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 0 7px 5px;'>£".$rate."</td>
  </tr>
  <tr>
    <td align='right' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 5px 7px 0;'>Store Name And Address:</td>
    <td align='left' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 0 7px 5px;'>".$store."</td>
  </tr>
  <tr>
    <td align='right' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 5px 7px 0;'>Store Timing</td>
    <td align='left' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 0 7px 5px;'>".$timing."</td>
  </tr>
  <tr>
    <td align='right' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 5px 7px 0;'>Testing Time:</td>
    <td align='left' valign='top' style='border-top:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 0 7px 5px;'>".$testTime."</td>
  </tr>
  <tr>
    <td align='right' valign='top' style='border-top:1px solid #dfdfdf; border-bottom:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 5px 7px 0;'>Special Request:</td>
    <td align='left' valign='top' style='border-top:1px solid #dfdfdf; border-bottom:1px solid #dfdfdf; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#000; padding:7px 0 7px 5px;'>".nl2br($speReq)."</td>
  </tr>
  <tr>
    <td colspan='2' align='center' valign='center' style='font-size: 10px'><center>E-Mail Powered By J-Solutions | All Rights Reserved ".date('Y')." | <a href='http://usman.jmobiles.pk'>http://usman.jmobiles.pk</a> | +92 334 5266444</center></td>
  </tr>
</table>

</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <noreply@jmobiles.pk>' . "\r\n";
echo $message;

   //if(mail($receiver,$subject,$message,$headers))  
   if(mail($receiver,$subject,$message,$headers))  
   {
      echo "The message has been sent!";
   }
   else
   {
      echo "The message could not been sent!";
   }


?>
