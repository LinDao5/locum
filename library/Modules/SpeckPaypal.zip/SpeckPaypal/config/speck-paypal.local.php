<?php
return array(
    'speck-paypal-api' => array(
       'username'      => 'pallavi.fwork22_api1.gmail.com',
      'password'      => '946HC8HVWZ4UJ89Y',
      'signature'     => 'AFcWxV21C7fd0v3bYYYRCpSSRl31AHuTIvTNlS0Fz9FK.e8lkk1S2cl2',
       'endpoint'               => 'https://api-3t.sandbox.paypal.com/nvp' //;Live URL: https://api-3t.paypal.com/nvp
    )
);